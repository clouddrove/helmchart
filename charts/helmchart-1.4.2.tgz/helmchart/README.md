# helmchart

![Version: 0.0.1](https://img.shields.io/badge/Version-0.0.1-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![version: 0.0.1](https://img.shields.io/badge/version-0.0.1-informational?style=flat-square)

A Helm chart for Kubernetes

**Homepage:** <https://github.com/clouddrove/helmchart>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| CloudDrove Inc | <hello@clouddrove.com> |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| autoscaling.customMetrics | list | `[]` | Raw HorizontalPodAutoscaler metric entries appended to spec.metrics. Use for Pods, Object, External or ContainerResource metrics, which the chart does not wrap. Needs an adapter serving them. Set autoscaling.targetCPUUtilizationPercentage to null to scale on these alone. |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `100` | The minimum amount of replicas allowed |
| autoscaling.minReplicas | int | `1` | Whether or not Horizontal Pod Autoscaler should be created, if false the Horizontal Pod Autoscaler will not be created |
| autoscaling.targetCPUUtilizationPercentage | int | `80` | The maximum amount of replicas allowed |
| configmap.configs.KEY | string | `"value"` |  |
| configmap.enabled | bool | `true` |  |
| fullnameOverride | string | `""` |  |
| image.pullPolicy | string | `"IfNotPresent"` | The container image repository that should be used.  E.g 'nginx', 'gcr.io/kubernetes-helm/tiller'.        |
| image.repository | string | `"nginx"` | Image to use for deploying, must support an entrypoint which creates users/databases from appropriate config files |
| image.tag | string | `""` | The image pull policy to employ. Determines when the image will be pulled in. If undefined, this will default to 'IfNotPresent'.   |
| imagePullSecrets | list | `[]` |  |
| ingress.annotations | object | `{}` |  |
| ingress.className | string | `""` | Specifies whether a ingress should be created |
| ingress.enabled | bool | `false` | ingress is a map that can be used to configure an Ingress resource for this service. |
| ingress.hosts | list | `[{"host":"chart-example.local","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}]` | Annotations that should be added to the Service resource. This is injected directly in to the resource yaml. kubernetes.io/ingress.class: nginx kubernetes.io/tls-acme: "true" |
| ingress.tls | list | `[]` |  |
| metrics.enabled | bool | `true` | Whether or not metrics should be created, if false the metrics will not be created |
| metrics.port | int | `3001` |  |
| metrics.portName | string | `"prometheus"` | portName specify the name of the port for the metrics resource.   |
| metrics.targetPort | int | `3001` |  |
| nameOverride | string | `""` | imagePullSecrets lists the Secret resources that should be used for accessing private registries. |
| nodeSelector | object | `{}` |  |
| pdbMinAvailable | string | `"30%"` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| poddisruptionbudget.enabled | bool | `false` |  |
| replicaCount | int | `1` |  |
| resources.limits | object | `{"cpu":"100m","memory":"128Mi"}` | We usually recommend not to specify default resources and to leave this as a conscious.  We usually recommend not to specify default resources and to leave this as a conscious. resources, such as Minikube. If you do want to specify resources, uncomment the following lines, adjust them as necessary, and remove the curly braces after 'resources:'.     |
| resources.requests.cpu | string | `"100m"` |  |
| resources.requests.memory | string | `"128Mi"` |  |
| secret.enabled | bool | `true` |  |
| secret.existingSecretName | string | `""` | Use an existing Secret instead of creating `<fullname>-secret`. |
| secret.secrets | object | `{"KEY":"value"}` | secrets is a map that specifies the Secret resources that should be exposed to the main application container.            |
| securityContext | object | `{}` |  |
| service.enabled | bool | `true` | service is a map that specifies the configuration for the Service resource that is created by the chart. |
| service.port | int | `80` | The Service type, as defined in Kubernetes. Defaults to ClusterIP. |
| service.type | string | `"ClusterIP"` | Specifies whether a service account should be created.         |
| serviceAccount.annotations | object | `{}` | Specifies whether a service account should be created |
| serviceAccount.enabled | bool | `true` |  |
| serviceAccount.name | string | `""` | Annotations to add to the service account |
| tolerations | list | `[]` |  |
| topologySpreadConstraints | list | `[]` | Pod topology spread constraints for the Deployment. A constraint without a labelSelector gets the chart's selector labels, so it spreads this release's pods. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.11.0](https://github.com/norwoodj/helm-docs/releases/v1.11.0)
